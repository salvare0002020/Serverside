package testDriver;

import java.util.ArrayList;

import dao.CustomerSearchDBAccess;
import model.Customer;


public class CDBATestDriver{

	public static void main(String[] args) throws Exception{
		CustomerSearchDBAccess dao = new CustomerSearchDBAccess();

		
/***serchcCustomerByTelテスト***/
		System.out.println("serchCustomerByTelテスト");
		//項番1
		try {
			System.out.println("***項番1***");
			ArrayList<Customer> list1
				= dao.serchCustomerByTel("08012345678");
			System.out.println("要素数：" + list1.size());
			for(int i = 0 ; i < list1.size() ; i++) {
				System.out.println("ID：" + list1.get(i).getCustId());
			}

			
		}catch(Exception e) {
			System.out.println("項番1　エラー\n" + e.getMessage());
		}
		
		//項番2		
		try {
			System.out.println("***項番2***");
			ArrayList<Customer> list2
				= dao.serchCustomerByTel("0314142135");
			System.out.println("要素数：" + list2.size());
			for(int i = 0 ; i < list2.size() ; i++) {
				System.out.println("ID：" + list2.get(i).getCustId());
			}

			
		}catch(Exception e) {
			System.out.println("項番2　エラー");
		}
		
		//項番3		
		try {
			System.out.println("***項番3***");
			ArrayList<Customer> list3
				= dao.serchCustomerByTel("07012345678");
			System.out.println("要素数：" + list3.size());
			for(int i = 0 ; i < list3.size() ; i++) {
				System.out.println("ID：" + list3.get(i).getCustId());
			}

			
		}catch(Exception e) {
			System.out.println("項番3　エラー");
		}

		//項番4		
		try {
			System.out.println("***項番4***");
			ArrayList<Customer> list4
				= dao.serchCustomerByTel("null");
			System.out.println("要素数：" + list4.size());
			for(int i = 0 ; i < list4.size() ; i++) {
				System.out.println("ID：" + list4.get(i).getCustId());
			}

			
		}catch(Exception e) {
			System.out.println("項番4　エラー");
		}
		
		//項番5		
		try {
			System.out.println("***項番5***");
			ArrayList<Customer> list5
				= dao.serchCustomerByTel("");
			System.out.println("要素数：" + list5.size());
			for(int i = 0 ; i < list5.size() ; i++) {
				System.out.println("ID：" + list5.get(i).getCustId());
			}

			
		}catch(Exception e) {
			System.out.println("項番5　エラー");
		}
		
		//項番6?7?		
		try {
			System.out.println("***項番7(6)***");
			CustomerSearchDBAccess dao6 = new CustomerSearchDBAccess();
			dao6.serchCustomerByTel("08012345678");
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	
		
		
/***serchCustomerByKanaテスト***/
		System.out.println("\nserchCustomerByKanaテスト");
		//項番1
		try {
			System.out.println("***項番1***");
			ArrayList<Customer> list1
				= dao.serchCustomerByKana("アオキ");
			System.out.println("要素数：" + list1.size());
			for(int i = 0 ; i < list1.size() ; i++) {
				System.out.println("ID：" + list1.get(i).getCustId());
			}

			
		}catch(Exception e) {
			System.out.println("項番1　エラー");
		}
		
		//項番2		
		try {
			System.out.println("***項番2***");
			ArrayList<Customer> list2
				= dao.serchCustomerByKana("イトウ");
			System.out.println("要素数：" + list2.size());
			for(int i = 0 ; i < list2.size() ; i++) {
				System.out.println("ID：" + list2.get(i).getCustId());
			}

			
		}catch(Exception e) {
			System.out.println("項番2　エラー");
		}
		
		//項番3		
		try {
			System.out.println("***項番3***");
			ArrayList<Customer> list3
				= dao.serchCustomerByKana("ササキ");
			System.out.println("要素数：" + list3.size());
			for(int i = 0 ; i < list3.size() ; i++) {
				System.out.println("ID：" + list3.get(i).getCustId());
			}

			
		}catch(Exception e) {
			System.out.println("項番3　エラー");
		}

		//項番4		
		try {
			System.out.println("***項番4***");
			ArrayList<Customer> list4
				= dao.serchCustomerByKana("null");
			System.out.println("要素数：" + list4.size());
			for(int i = 0 ; i < list4.size() ; i++) {
				System.out.println("ID：" + list4.get(i).getCustId());
			}

			
		}catch(Exception e) {
			System.out.println("項番4　エラー");
		}
		
		//項番5		
		try {
			System.out.println("***項番5***");
			ArrayList<Customer> list5
				= dao.serchCustomerByKana("");
			System.out.println("要素数：" + list5.size());
			for(int i = 0 ; i < list5.size() ; i++) {
				System.out.println("ID：" + list5.get(i).getCustId());
			}

			
		}catch(Exception e) {
			System.out.println("項番5　エラー");
		}
		
		//項番6?7?		
		try {
			System.out.println("***項番7(6)***");
			CustomerSearchDBAccess dao6 = new CustomerSearchDBAccess();
			dao6.serchCustomerByKana("アオキ");
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		
		
		/***serchCustomerテスト***/
		System.out.println("\nserchCustomerテスト");
		//項番1
		try {
			System.out.println("***項番1***");
			ArrayList<Customer> list1
				= dao.serchCustomer("09023456781" , "イトウ");
			System.out.println("要素数：" + list1.size());
			for(int i = 0 ; i < list1.size() ; i++) {
				System.out.println("ID：" + list1.get(i).getCustId());
			}

			
		}catch(Exception e) {
			System.out.println("項番1　エラー");
		}
		
		//項番2		
		try {
			System.out.println("***項番2***");
			ArrayList<Customer> list2
				= dao.serchCustomer("0314142135" , "コ");
			System.out.println("要素数：" + list2.size());
			for(int i = 0 ; i < list2.size() ; i++) {
				System.out.println("ID：" + list2.get(i).getCustId());
			}

			
		}catch(Exception e) {
			System.out.println("項番2　エラー");
		}
		
		//項番3		
		try {
			System.out.println("***項番3***");
			ArrayList<Customer> list3
				= dao.serchCustomer("08012345678" , "アオキ");
			System.out.println("要素数：" + list3.size());
			for(int i = 0 ; i < list3.size() ; i++) {
				System.out.println("ID：" + list3.get(i).getCustId());
			}

			
		}catch(Exception e) {
			System.out.println("項番3　エラー");
		}

		//項番4		
		try {
			System.out.println("***項番4***");
			ArrayList<Customer> list4
				= dao.serchCustomer("07012345678" , "イトウ");
			System.out.println("要素数：" + list4.size());
			for(int i = 0 ; i < list4.size() ; i++) {
				System.out.println("ID：" + list4.get(i).getCustId());
			}

			
		}catch(Exception e) {
			System.out.println("項番4　エラー");
		}
		
		//項番5		
		try {
			System.out.println("***項番5***");
			ArrayList<Customer> list5
				= dao.serchCustomer("09012345678" , "ササキ");
			System.out.println("要素数：" + list5.size());
			for(int i = 0 ; i < list5.size() ; i++) {
				System.out.println("ID：" + list5.get(i).getCustId());
			}

			
		}catch(Exception e) {
			System.out.println("項番5　エラー");
		}
		
		//項番6		
		try {
			System.out.println("***項番6***");
			ArrayList<Customer> list6
				= dao.serchCustomer("" , "");
			System.out.println("要素数：" + list6.size());
			for(int i = 0 ; i < list6.size() ; i++) {
				System.out.println("ID：" + list6.get(i).getCustId());
			}

			
		}catch(Exception e) {
			System.out.println("項番6　エラー");
		}
		
		//項番7		
		try {
			System.out.println("***項番7***");
			ArrayList<Customer> list7
				= dao.serchCustomer("null" , "null");
			System.out.println("要素数：" + list7.size());
			for(int i = 0 ; i < list7.size() ; i++) {
				System.out.println("ID：" + list7.get(i).getCustId());
			}

			
		}catch(Exception e) {
			System.out.println("項番7　エラー");
		}
		
		//項番8?9?	
		try {
			System.out.println("***項番8(9)***");
			CustomerSearchDBAccess dao8 = new CustomerSearchDBAccess();
			dao8.serchCustomer("09023456781" , "イトウ");
			
		}catch(Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		
	}

}
