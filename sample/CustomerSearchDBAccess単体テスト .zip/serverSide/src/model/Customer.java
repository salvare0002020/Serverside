package model;

public class Customer {

	private int custId;
	private String name;
	private String kana;
	private String telNum;
	private String address;

//	public Customer(int custId , String name , String telNum , String address) {
//		this.custId = custId;
//		this.name = name;
//		this.telNum = telNum;
//		this.address = address;
//	}

	public Customer(int custId, String name, String kana, String telNum, String address) {
		this.custId = custId;
		this.name = name;
		this.kana = kana;
		this.telNum = telNum;
		this.address = address;
	}
	

	public int getCustId() {
		return custId;
	}

	public String getName() {
		return name;
	}
	
	public String getKana() {
		return kana;
	}
	
	public String getTelNum() {
		return telNum;
	}
	
	public String getAddres() {
		return address;
	}


}
