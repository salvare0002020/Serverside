
/*
 * クラス名：    Customer
 * 概要　　：    顧客情報
 * 作成者名：	 緋田竜也
 * 作成日　：	 2023/5/19
 * 修正者名：
 * 修正日　：
 */
package action;

//import java.util.ArrayList;
//import model.Customer;
//import model.OrderControlUnity;
//import dao.CustomerSearchDBAccess;

public class CustomerSearchAction {
	public String[][] execute(String[] data)throws Exception{
		data[0] = data[0].replaceAll("　| ", "");
		data[1] = data[1].replaceAll("　| ", "");
		if(!(data[0].equals("")) && data[1].equals("")){
			
		}else if(data[0].equals("") && !(data[1].equals(""))){
			
		}else if(!(data[0].equals("")) && !(data[1].equals(""))){
			
		}
		String[][] tabledata = new String[1][2];
		tabledata[0][0] = data[0];
		tabledata[0][1] = data[1];
		return tabledata ;
	}

}
