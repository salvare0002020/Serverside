package action;

import control.KiddaLaController;

public class KiddaLaControllerdriver {

	

	public static void main(String[] args) {
		String[] data = {"09012345678","アオキマユミ"};
		String[][] tableData = null;
		
		KiddaLaController kc = new KiddaLaController();
		try {
			tableData = KiddaLaController.customerSearch(data);
			System.out.println(tableData[0][0] + tableData[0][1] );
		} catch (Exception e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		
		data[0] = "09034567812";
		data[1] = "シバタリュウイチ";
		try {
			tableData = KiddaLaController.customerSearch(data);
			System.out.println(tableData[0][0] + tableData[0][1] );
		} catch (Exception e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

	}

}
