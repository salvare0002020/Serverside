package unittest.uc1;

import model.Customer;

//単体番号Ⅰ　ドライバクラス（Cusomerクラス）
public class UnitTest_Customer {

	public static void main(String[] args) {
		//項番1
		Customer product1 = new Customer(1,"青木まゆみ", "アオキマユミ","09012345678", "東京都千代田区神田小川町1-1-1");
		System.out.println("--項番1------------------");
		System.out.println(product1.getCustId());
		System.out.println(product1.getCustName());
		System.out.println(product1.getKana());
		System.out.println(product1.getTel());
		System.out.println(product1.getAddress());
		
		//項番2
		Customer product2 = new Customer(0,null,null,null,null);
		System.out.println("--項番2------------------");
		System.out.println(product2.getCustId());
		System.out.println(product2.getCustName());
		System.out.println(product2.getKana());
		System.out.println(product2.getTel());
		System.out.println(product2.getAddress());
		
		//項番3, 5
		Customer product3 = new Customer();
		System.out.println("--項番3, 5------------------");
		product3.setCustId(2);//項番3
		System.out.println(product3.getCustId());//項番5
		
		//項番4, 6
		Customer product4 = new Customer();
		System.out.println("--項番4, 6------------------");
		product4.setCustId(0);//項番4
		System.out.println(product4.getCustId());//項番6
		
		//項番7, 9
		Customer product7 = new Customer();
		System.out.println("--項番7, 9------------------");
		product7.setCustName("伊藤華英");//項番7
		System.out.println(product7.getCustName());//項番9
		
		//項番8, 10
		Customer product8 = new Customer();
		System.out.println("--項番8, 10------------------");
		product8.setCustName("null");//項番8
		System.out.println(product8.getCustName());//項番10
		
		//項番11, 13
		Customer product11 = new Customer();
		System.out.println("--項番11, 13------------------");
		product11.setKana("イトウハナエ");//項番11
		System.out.println(product11.getKana());//項番13
		
		//項番12, 14
		Customer product12 = new Customer();
		System.out.println("--項番12, 14------------------");
		product12.setKana("null");//項番12
		System.out.println(product12.getKana());//項番14
		
		//項番15, 17
		Customer product15 = new Customer();
		System.out.println("--項番15, 17------------------");
		product15.setTel("09023456781");//項番15
		System.out.println(product15.getTel());//項番17
		
		//項番16, 18
		Customer product16 = new Customer();
		System.out.println("--項番16, 18------------------");
		product16.setTel("null");//項番16
		System.out.println(product16.getTel());//項番18
		
		//項番19, 21
		Customer product19 = new Customer();
		System.out.println("--項番19, 21------------------");
		product19.setAddress("東京都千代田区神田小川町2-1-1");//項番19
		System.out.println(product19.getAddress());//項番21
		
		//項番20, 22
		Customer product20 = new Customer();
		System.out.println("--項番20, 22------------------");
		product20.setAddress("null");//項番20
		System.out.println(product20.getAddress());//項番22
	}

}
